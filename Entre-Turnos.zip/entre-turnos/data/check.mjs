import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { margin, inversion, referenceYear, share } from '../src/model.ts';
import { output, states, years } from './sources.mjs';

const json = async name => JSON.parse(await readFile(join(output, name), 'utf8'));
const manifest = await json('index.json');
const context = await json('context.json');
assert.deepEqual(manifest.years, years);
assert.equal(Object.keys(manifest.ufs).length, 27);

// Publicações do TSE, segundo turno, incluindo exterior para presidente.
const official = {
  2018: [57797847, 47040906],
  2022: [60345999, 58206354],
  2026: [64256232, 59826041],
};

for (const year of years) {
  const audit = await json(`audit-${year}.json`);
  assert.deepEqual(audit.missingCodes, [], `códigos não mapeados em ${year}`);
  assert.deepEqual(audit.discrepancies, [], `votos válidos divergentes em ${year}`);
  const tally = entry => Object.values(entry.votes[2]).sort((a, b) => b - a);
  assert.deepEqual(tally(audit.official['P-BR']), official[year]);
  const national = await json(`results-${year}-BR.json`);
  assert.equal(Object.keys(national.rows).length, 27);
  for (const uf of Object.keys(states)) {
    const { rows } = await json(`results-${year}-${uf}.json`);
    const geometry = await json(`geo-${uf}.geojson`);
    const ids = new Set(geometry.features.map(feature => feature.id));
    for (const [id, races] of Object.entries(rows)) {
      assert.ok(ids.has(id), `geometria ausente para ${id} em ${year}`);
      for (const rounds of Object.values(races)) {
        for (const [eligible, turnout, valid] of Object.values(rounds)) {
          assert.ok(eligible >= turnout && turnout >= valid && valid >= 0, `apuração incoerente para ${id}`);
        }
      }
    }
    const stateRounds = national.rows[uf].G;
    if (!stateRounds[2]) assert.equal(manifest.races[year][`G-${uf}`].rounds.includes(2), false);
  }
  if (year === 2026) {
    assert.deepEqual(tally(audit.official['G-ES']), [1151818, 1056119]);
    assert.equal(Object.values(national.rows).filter(row => row.G[2]).length, 6);
  }
}

const { rows: espiritoSanto } = await json('results-2026-ES.json');
const victoria = espiritoSanto['3205309'];
const vilaVelha = espiritoSanto['3205200'];
const governor = manifest.races[2026]['G-ES'];
const pair = governor.pair;
assert.deepEqual(governor.rounds, [1, 2]);
assert.deepEqual([victoria.G[2][5][pair[0]], victoria.G[2][5][pair[1]]], [112161, 96451]);
assert.deepEqual([vilaVelha.G[2][5][pair[0]], vilaVelha.G[2][5][pair[1]]], [143435, 120240]);
assert.equal(margin(undefined, pair), null);
assert.equal(share(4, 0), null);
assert.equal(inversion(0, -6), false);
assert.equal(inversion(-4, 6), true);
assert.equal(referenceYear(context.indicators, 'homicides', 2026, Object.keys(states)), 2024);
assert.equal(referenceYear(context.indicators, 'homicides', 2022, Object.keys(states)), 2021);
assert.equal(referenceYear(context.indicators, 'income', 2026, Object.keys(states)), 2025);
assert.ok(context.terms.some(term => term.id === 'ES' && term.name === 'Ricardo Ferraço' && term.start === '2026-04-02'));
assert.ok(!(await json('results-2022-MT.json')).rows['5101837']);
assert.ok((await json('results-2026-MT.json')).rows['5101837']);
console.log('OK · votos oficiais de 3 pleitos, 81 pares UF/ano, recortes municipais, indicadores e casos de ausência.');
