import { spawnSync } from 'node:child_process';
import { mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { gzipSync } from 'node:zlib';

const dist = resolve('.data/offline');
const target = resolve(process.argv[2] ?? '../Entre-Turnos.html');
const build = spawnSync(process.execPath, ['node_modules/vite/bin/vite.js', 'build', '--outDir', dist, '--emptyOutDir'], {
  env: { ...process.env, ENTRE_TURNOS_OFFLINE: '1' }, stdio: 'inherit',
});
if (build.status !== 0) process.exit(build.status ?? 1);

const entry = await readFile(join(dist, 'index.html'), 'utf8');
const bundle = entry.match(/<script type="module"[^>]+src="([^"]+)"[^>]*><\/script>/);
const style = entry.match(/<link rel="stylesheet"[^>]+href="([^"]+)"[^>]*>/);
if (!bundle || !style) throw new Error('Arquivos compilados do atlas não encontrados.');
const javascript = (await readFile(join(dist, bundle[1]), 'utf8')).replace(/<\/script/gi, '<\\/script');
const css = await readFile(join(dist, style[1]), 'utf8');
const dataDir = 'public/data';
const dataNames = (await readdir(dataDir)).filter(name => !name.startsWith('audit-'));
const data = {};
for (const name of dataNames) {
  data[name] = gzipSync(await readFile(join(dataDir, name))).toString('base64');
}
const html = entry
  .replace(bundle[0], () => `<script>window.entreTurnosData = ${JSON.stringify(data)};</script><script type="module">${javascript}</script>`)
  .replace(style[0], () => `<style>${css}</style>`);
await mkdir(dirname(target), { recursive: true });
await writeFile(target, html, 'utf8');
console.log(`Atlas offline · ${(Buffer.byteLength(html) / 1_000_000).toFixed(1)} MB`);
