import { DuckDBInstance } from '@duckdb/node-api';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { aggregate, assemble } from './election.mjs';
import { buildGeometry } from './geometry.mjs';
import { raw, output, states, years } from './sources.mjs';
import { extract } from './zip.mjs';
import { buildContext } from './context.mjs';

const pilot = process.argv.includes('--pilot');
const geometryOnly = process.argv.includes('--geometry-only');
const electionsOnly = process.argv.includes('--elections-only');
const contextOnly = process.argv.includes('--context-only');
const cache = resolve(process.env.ENTRE_TURNOS_CACHE ?? '.data/cache');
const biDir = resolve('bi/data');
const target = pilot ? resolve('public/pilot') : output;
const targetYears = pilot ? [2026] : years;
const targetUfs = pilot ? ['ES'] : Object.keys(states);
await Promise.all([mkdir(cache, { recursive: true }), mkdir(target, { recursive: true }), mkdir(biDir, { recursive: true })]);

const writeJson = (name, data) => writeFile(join(target, name), JSON.stringify(data) + '\n', 'utf8');
const csvEscape = value => `"${String(value ?? '').replaceAll('"', '""')}"`;
async function csv(name, rows) {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const lines = rows.map(row => keys.map(key => csvEscape(row[key])).join(','));
  await writeFile(join(biDir, `${name}.csv`), [keys.join(','), ...lines, ''].join('\n'), 'utf8');
}

if (!electionsOnly && !contextOnly) {
  for (const uf of ['BR', ...targetUfs]) {
    const geometry = await buildGeometry(uf, target, cache);
    await writeJson(`geo-${uf}.geojson`, geometry);
    console.log(`IBGE ${uf} · ${geometry.features.length} polígonos`);
  }
}

if (!geometryOnly && !contextOnly) {
  const instance = await DuckDBInstance.create(':memory:', { threads: '6', preserve_insertion_order: 'false' });
  const db = await instance.connect();
  const selected = name =>
    /\.csv$/i.test(name) && ['_BR.csv', ...targetUfs.map(uf => `_${uf}.csv`)].some(suffix => name.endsWith(suffix));
  const [crosswalkPath] = await extract(join(raw, 'crosswalk.zip'), join(cache, 'crosswalk'), name => name.endsWith('.csv'));
  const manifest = { years: targetYears, ufs: Object.fromEntries(targetUfs.map(uf => [uf, states[uf]])),
    locations: {}, races: {}, snapshots: {}, pilot };
  const tables = { votes: [], counts: [], candidates: [] };
  for (const year of targetYears) {
    console.log(`TSE ${year} · extraindo arquivos e agregando votações e apuração`);
    const [votesPaths, countsPaths] = await Promise.all(['votes', 'counts'].map(kind =>
      extract(join(raw, `${kind}-${year}.zip`), join(cache, `${kind}-${year}`), selected)));
    const edition = assemble(year, await aggregate(db, { votesPaths, countsPaths, crosswalkPath, pilot }));
    if (edition.audit.discrepancies.length) {
      throw new Error(`Votos válidos divergentes em ${year}: ${JSON.stringify(edition.audit.discrepancies.slice(0, 5))}`);
    }
    const writes = Object.entries(edition.states).map(([uf, rows]) =>
      writeJson(`results-${year}-${uf}.json`, { rows }));
    await Promise.all([...writes, writeJson(`results-${year}-BR.json`, { rows: edition.ufs, domestic: edition.domestic }),
      writeJson(`audit-${year}.json`, edition.audit)]);
    Object.assign(manifest.locations, edition.locations);
    manifest.races[year] = edition.races;
    manifest.snapshots[year] = edition.audit.snapshots;
    for (const key of Object.keys(tables)) tables[key].push(...edition.tables[key]);
    console.log(`TSE ${year} · ${Object.keys(edition.states).length} UFs, ${Object.keys(edition.locations).length} localidades, ${edition.audit.missingCodes.length} códigos sem equivalência`);
  }
  await writeJson('index.json', manifest);
  if (!pilot) {
    await Promise.all([
      ...Object.entries(tables).map(([table, rows]) => csv(table, rows)),
      csv('municipalities', Object.entries(manifest.locations).map(([id, data]) => ({ id, ...data }))),
      csv('states', Object.entries(states).map(([uf, data]) => ({ uf, name: data.name }))),
      csv('years', years.map(year => ({ year }))),
      csv('rounds', [{ round: 1, label: '1º turno' }, { round: 2, label: '2º turno' }]),
      csv('offices', [{ office: 'Presidente' }, { office: 'Governador' }]),
    ]);
  }
  db.closeSync();
}

if (!pilot && !geometryOnly && !electionsOnly) {
  const manifest = JSON.parse(await readFile(join(target, 'index.json'), 'utf8'));
  const context = await buildContext(manifest);
  await writeJson('context.json', context);
  await Promise.all([
    csv('indicators', context.indicators.map(row => ({ id: row.id, year: row.year, metric: row.metric, value: row.value }))),
    csv('terms', context.terms),
  ]);
  console.log(`Contexto · ${context.indicators.length} observações e ${context.terms.length} mandatos`);
}
