import { createWriteStream } from 'node:fs';
import { mkdir, rename, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { archiveUrls, contextualUrls, raw } from './sources.mjs';

const pilot = process.argv.includes('--pilot');
const refresh = process.argv.includes('--refresh');
const urls = pilot ? Object.entries(archiveUrls).filter(([name]) =>
  ['votes-2026.zip', 'counts-2026.zip', 'crosswalk.zip', 'geo-es.zip', 'geo-uf.zip'].includes(name),
) : Object.entries({ ...archiveUrls, ...contextualUrls });
const pending = urls.values();
const errors = [];
await mkdir(raw, { recursive: true });

async function download(name, url) {
  const path = join(raw, name);
  if (!refresh && await stat(path).then(file => file.size > 0, () => false)) return;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(900_000) });
      if (!response.ok || !response.body) throw new Error(`HTTP ${response.status}`);
      await pipeline(Readable.fromWeb(response.body), createWriteStream(`${path}.part`));
      const size = (await stat(`${path}.part`)).size;
      if (!size) throw new Error('arquivo vazio');
      await rename(`${path}.part`, path);
      console.log(`${name} · ${(size / 1_000_000).toFixed(1)} MB`);
      return;
    } catch (error) {
      await rm(`${path}.part`, { force: true });
      if (attempt === 3) errors.push(`${name}: ${error.message}`);
    }
  }
}

await Promise.all(Array.from({ length: 4 }, async () => {
  for (const [name, url] of pending) await download(name, url);
}));
if (errors.length) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
}
