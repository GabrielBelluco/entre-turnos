import { createWriteStream } from 'node:fs';
import { mkdir, rename, rm, stat } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { pipeline } from 'node:stream/promises';
import yauzl from 'yauzl';

export async function extract(zipPath, directory, select) {
  await mkdir(directory, { recursive: true });
  const zip = await new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true, autoClose: false }, (error, file) => {
      if (error) reject(error);
      else resolve(file);
    });
  });
  const names = [];
  try {
    for (;;) {
      const entry = await new Promise((resolve, reject) => {
        const onEnd = () => { zip.off('entry', onEntry); resolve(null); };
        const onEntry = value => { zip.off('end', onEnd); resolve(value); };
        zip.once('entry', onEntry);
        zip.once('end', onEnd);
        zip.once('error', reject);
        zip.readEntry();
      });
      zip.removeAllListeners('error');
      if (!entry) return names;
      const name = basename(entry.fileName);
      if (!select(name)) continue;
      const path = join(directory, name);
      names.push(path);
      if (await stat(path).then(file => file.size === entry.uncompressedSize, () => false)) continue;
      const stream = await new Promise((resolve, reject) => {
        zip.openReadStream(entry, (error, result) => error ? reject(error) : resolve(result));
      });
      try {
        await pipeline(stream, createWriteStream(`${path}.part`));
        await rename(`${path}.part`, path);
      } finally {
        await rm(`${path}.part`, { force: true });
      }
    }
  } finally {
    zip.close();
  }
}
