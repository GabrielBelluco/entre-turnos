import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { raw, states } from './sources.mjs';

const readJson = async path => JSON.parse(await readFile(path, 'utf8'));
const codes = Object.fromEntries(Object.entries(states).map(([uf, value]) => [value.id, uf]));
const reference = name => new URL(`./reference/${name}`, import.meta.url);

function parseTerms(text) {
  const rows = [];
  let id, defaultSource;
  for (const line of text.trim().split(/\r?\n/)) {
    const [key, name, note = '', link = ''] = line.split('|');
    if (key.startsWith('@')) {
      id = key.slice(1);
      defaultSource = name.startsWith('wiki:') ? `https://pt.wikipedia.org/wiki/Lista_de_governadores_${encodeURIComponent(name.slice(5))}` : name;
    } else {
      const previous = rows.at(-1);
      if (previous?.id === id) previous.end = key;
      rows.push({ id, name, start: key, end: null, source: link || defaultSource, note });
    }
  }
  return rows;
}

export async function buildContext(manifest) {
  const [referenceSeries, termText, jobs, income, literacy] = await Promise.all([
    readJson(reference('series.json')), readFile(reference('terms.txt'), 'utf8'),
    ...['jobs.json', 'income-real.json', 'literacy.json'].map(name => readJson(join(raw, name))),
  ]);
  const sidra = (source, metric, variable, location) => source.slice(1)
    .filter(row => row.D2C === variable && /^\d+(\.\d+)?$/.test(row.V))
    .map(row => ({ id: location(row), year: Number(row.D3C), metric, value: Number(row.V) }))
    .filter(row => row.id);
  const uf = row => row.NC === '1' ? 'BR' : codes[row.D1C];
  const indicators = [
    ...referenceSeries.filter(row => row.metric !== 'idhmMunicipal' || manifest.locations[row.id]),
    ...sidra(jobs, 'jobs', '4099', uf),
    ...sidra(income, 'income', '10816', uf),
    ...sidra(literacy, 'literacy', '2513', row => manifest.locations[row.D1C] ? row.D1C : null),
  ];
  const keys = indicators.map(row => `${row.id}/${row.year}/${row.metric}`);
  if (new Set(keys).size !== keys.length) throw new Error('Indicadores repetidos na mesma geografia, ano e série.');
  for (const metric of ['idhm', 'homicides', 'jobs', 'income']) {
    if (new Set(indicators.filter(row => row.metric === metric).map(row => row.id)).size !== 28) {
      throw new Error(`Cobertura incompleta da série ${metric}`);
    }
  }
  const terms = parseTerms(termText);
  if (new Set(terms.map(term => term.id)).size !== 28) throw new Error('Cobertura de mandatos incompleta.');
  const lastEnd = {};
  for (const term of terms.sort((a, b) => a.id.localeCompare(b.id) || a.start.localeCompare(b.start))) {
    if (term.end && term.start >= term.end) throw new Error(`Mandato inválido: ${term.name}`);
    if (lastEnd[term.id] && term.start < lastEnd[term.id]) throw new Error(`Mandatos sobrepostos em ${term.id}`);
    lastEnd[term.id] = term.end ?? '9999-12-31';
  }
  return { indicators, terms };
}
