import { execFile } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { promisify } from 'node:util';
import { extract } from './zip.mjs';
import { raw } from './sources.mjs';

const run = promisify(execFile);

export async function buildGeometry(uf, output, cache) {
  const national = uf === 'BR';
  const code = national ? 'uf' : uf.toLowerCase();
  const files = await extract(join(raw, `geo-${code}.zip`), join(cache, `geo-${code}`),
    name => /\.(shp|shx|dbf|prj|cpg)$/i.test(name) && name.includes(national ? '_UF_' : '_Municipios_'));
  const input = files.find(name => name.endsWith('.shp'));
  if (!input) throw new Error(`Shapefile ausente em geo-${code}.zip`);
  const path = join(output, `geo-${uf}.geojson`);
  await run(process.execPath, [
    resolve('node_modules/mapshaper/bin/mapshaper'), input,
    '-proj', 'wgs84',
    '-simplify', 'weighted', `interval=${national ? 1800 : 350}m`, 'keep-shapes',
    '-filter-fields', national ? 'SIGLA_UF,NM_UF' : 'CD_MUN,NM_MUN',
    '-o', 'force', 'format=geojson', 'precision=0.00001', path,
  ], { maxBuffer: 2_000_000, timeout: 180_000 });
  const result = JSON.parse(await readFile(path, 'utf8'));
  const features = result.features.map(feature => {
    const id = national ? feature.properties.SIGLA_UF : String(feature.properties.CD_MUN);
    const name = national ? feature.properties.NM_UF : feature.properties.NM_MUN;
    if (!id || !name || !feature.geometry) throw new Error(`Geometria sem chave ou polígono em ${uf}: ${id}`);
    return { ...feature, id, properties: { id, name } };
  });
  if (new Set(features.map(feature => feature.id)).size !== features.length) throw new Error(`Geometrias duplicadas em ${uf}`);
  return { type: 'FeatureCollection', features };
}
