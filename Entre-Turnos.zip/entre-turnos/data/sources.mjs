import { resolve } from 'node:path';

export const raw = resolve(process.env.ENTRE_TURNOS_RAW ?? '.data/raw');
export const output = resolve('public/data');
export const years = [2018, 2022, 2026];
export const states = Object.fromEntries([
  ['RO', 11, 'Rondônia'], ['AC', 12, 'Acre'], ['AM', 13, 'Amazonas'], ['RR', 14, 'Roraima'],
  ['PA', 15, 'Pará'], ['AP', 16, 'Amapá'], ['TO', 17, 'Tocantins'],
  ['MA', 21, 'Maranhão'], ['PI', 22, 'Piauí'], ['CE', 23, 'Ceará'], ['RN', 24, 'Rio Grande do Norte'],
  ['PB', 25, 'Paraíba'], ['PE', 26, 'Pernambuco'], ['AL', 27, 'Alagoas'], ['SE', 28, 'Sergipe'],
  ['BA', 29, 'Bahia'], ['MG', 31, 'Minas Gerais'], ['ES', 32, 'Espírito Santo'],
  ['RJ', 33, 'Rio de Janeiro'], ['SP', 35, 'São Paulo'], ['PR', 41, 'Paraná'],
  ['SC', 42, 'Santa Catarina'], ['RS', 43, 'Rio Grande do Sul'],
  ['MS', 50, 'Mato Grosso do Sul'], ['MT', 51, 'Mato Grosso'], ['GO', 52, 'Goiás'], ['DF', 53, 'Distrito Federal'],
].map(([uf, id, name]) => [uf, { id: String(id), name }]));

const tse = 'https://cdn.tse.jus.br/estatistica/sead/odsele';
const mesh = 'https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_municipais/municipio_2025';
export const archiveUrls = Object.fromEntries(years.flatMap(year => [
  [`votes-${year}.zip`, `${tse}/votacao_candidato_munzona/votacao_candidato_munzona_${year}.zip`],
  [`counts-${year}.zip`, `${tse}/detalhe_votacao_munzona/detalhe_votacao_munzona_${year}.zip`],
]).concat([
  ['crosswalk.zip', `${tse}/municipio_tse_ibge/municipio_tse_ibge.zip`],
  ['geo-uf.zip', `${mesh}/Brasil/BR_UF_2025.zip`],
  ...Object.keys(states).map(uf => [`geo-${uf.toLowerCase()}.zip`, `${mesh}/UFs/${uf}/${uf}_Municipios_2025.zip`]),
]));

export const contextualUrls = {
  'jobs.json': 'https://apisidra.ibge.gov.br/values/t/10361/n3/all/n1/all/v/4099/p/all/c86/95251',
  'income-real.json': 'https://apisidra.ibge.gov.br/values/t/7533/n3/all/n1/all/v/all/p/all/c1019/49243',
  'literacy.json': 'https://apisidra.ibge.gov.br/values/t/9543/n6/all/v/2513/p/2022',
  'violencia.pdf': 'https://repositorio.ipea.gov.br/server/api/core/bitstreams/6e855a6f-1a5d-494d-90aa-753862e10369/content',
  'radar.pdf': 'https://ifz.org.br/download/21036/?tmstv=1779828564&v=21037',
  'pnud-min.rda': 'https://raw.githubusercontent.com/abjur/abjData/master/data/pnud_min.rda',
};
