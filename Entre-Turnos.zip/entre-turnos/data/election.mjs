const quote = input => "'" + String(input).replaceAll("'", "''") + "'";
const strings = items => items.map(quote).join(', ');
const csv = paths => `read_csv([${strings(paths)}], header=true, delim=';', all_varchar=true, encoding='latin-1', quote='"', escape='"', sample_size=2048)`;
const contestFilter = `CD_TIPO_ELEICAO = '2' and NR_TURNO in ('1','2') and CD_CARGO in ('1','3')`;

export const reader = async (db, statement) => (await db.runAndReadAll(statement)).getRowObjectsJS();

export async function aggregate(db, { votesPaths, countsPaths, crosswalkPath, pilot }) {
  await db.run(`
    create or replace temporary table crosswalk as
    select distinct SG_UF as uf, lpad(CD_MUNICIPIO_TSE, 5, '0') as tse, CD_MUNICIPIO_IBGE as ibge,
           NM_MUNICIPIO_IBGE as name
    from ${csv([crosswalkPath])}
    where regexp_full_match(CD_MUNICIPIO_IBGE, '[0-9]{7}')
  `);
  const conflicts = await reader(db, 'select uf, tse from crosswalk group by all having count(*) > 1');
  if (conflicts.length) throw new Error(`Códigos TSE ambíguos: ${JSON.stringify(conflicts)}`);

  const geography = `coalesce(m.ibge, 'tse:' || f.SG_UF || ':' || f.CD_MUNICIPIO)`;
  const from = paths => `from ${csv(paths)} f
    left join crosswalk m on m.uf = f.SG_UF and m.tse = lpad(f.CD_MUNICIPIO,5,'0')
    where ${contestFilter} ${pilot ? "and SG_UF in ('ES','ZZ')" : ''}`;
  const keys = `SG_UF uf, ${geography} id, cast(CD_CARGO as integer) office,
                 cast(NR_TURNO as integer) round, max(CD_ELEICAO) election`;

  // O arquivo BR contém a Presidência. Os arquivos por UF contêm as disputas estaduais.
  const localVotes = await reader(db, `
    select ${keys}, min(coalesce(m.name, NM_MUNICIPIO)) as "name", SQ_CANDIDATO as candidate,
           max(NR_CANDIDATO) number, max(NM_URNA_CANDIDATO) ballot, max(SG_PARTIDO) party,
           cast(sum(cast(QT_VOTOS_NOMINAIS_VALIDOS as bigint)) as double) votes,
           bool_or(CD_SIT_TOT_TURNO = '1') elected,
           max(DT_GERACAO) as snapshot, cast(count(distinct CD_ELEICAO) as integer) as electionCount
    ${from(votesPaths)}
    group by 1, 2, 3, 4, 7
    having votes > 0
    order by uf, id, office, round, candidate
  `);
  const localCounts = await reader(db, `
    select ${keys}, min(coalesce(m.name, NM_MUNICIPIO)) as "name",
           cast(sum(cast(QT_APTOS as bigint)) as double) eligible,
           cast(sum(cast(QT_COMPARECIMENTO as bigint)) as double) turnout,
           cast(sum(cast(QT_TOTAL_VOTOS_VALIDOS as bigint)) as double) as "valid",
           cast(sum(cast(QT_VOTOS_BRANCOS as bigint)) as double) blank,
           cast(sum(cast(QT_TOTAL_VOTOS_NULOS as bigint)) as double) invalid,
           cast(count(distinct CD_ELEICAO) as integer) as electionCount
    ${from(countsPaths)}
    group by 1, 2, 3, 4
    order by uf, id, office, round
  `);
  if ([...localVotes, ...localCounts].some(row => row.electionCount !== 1)) {
    throw new Error('Mais de uma eleição ordinária na mesma chave. Inspecione CD_ELEICAO.');
  }
  return { localVotes, localCounts };
}

const officeKey = { 1: 'P', 3: 'G' };
const officeName = { 1: 'Presidente', 3: 'Governador' };
const addTo = (object, key, value) => { object[key] = (object[key] ?? 0) + value; };
const countKeys = ['eligible','turnout','valid','blank','invalid'];
const emptyCounts = () => Object.fromEntries(countKeys.map(key => [key, 0]));
const newResult = counts => [counts.eligible, counts.turnout, counts.valid, counts.blank, counts.invalid, {}];
const resultKey = row => `${row.id}/${row.office}/${row.round}`;
const raceKey = row => row.office === 1 ? 'P-BR' : `G-${row.uf}`;

export function assemble(year, { localVotes, localCounts }) {
  const states = {};
  const ufs = {};
  const domestic = {};
  const external = {};
  const locations = {};
  const metadata = {};
  const contestSums = {};
  const scopeCounts = {};
  const audit = { year, missingCodes: [], turnoutDifferences: [], discrepancies: [], snapshots: [], official: {} };
  const municipal = new Map();

  for (const row of localCounts) {
    const office = officeKey[row.office];
    const territorial = row.uf === 'ZZ' ? external : (states[row.uf] ??= {});
    const races = territorial[row.id] ??= {};
    const rounds = races[office] ??= {};
    const counts = rounds[row.round] = newResult(row);
    municipal.set(resultKey(row), counts);
    if (row.uf !== 'ZZ') {
      locations[row.id] = { uf: row.uf, name: row.name };
      if (row.id.startsWith('tse:') && !audit.missingCodes.includes(row.id)) audit.missingCodes.push(row.id);
      const ufOffice = (ufs[row.uf] ??= {});
      const stateRound = ((ufOffice[office] ??= {})[row.round] ??= newResult(emptyCounts()));
      countKeys.forEach((key, index) => { stateRound[index] += row[key]; });
      if (office === 'P') {
        const total = domestic[row.round] ??= newResult(emptyCounts());
        countKeys.forEach((key, index) => { total[index] += row[key]; });
      }
    }
    const scope = raceKey(row);
    const round = ((scopeCounts[scope] ??= {})[row.round] ??= emptyCounts());
    countKeys.forEach(key => { round[key] += row[key]; });
  }

  for (const row of localVotes) {
    const local = municipal.get(resultKey(row));
    if (!local) throw new Error(`Apuração ausente para votação: ${resultKey(row)}`);
    const scope = raceKey(row);
    const candidate = row.candidate;
    const office = officeKey[row.office];
    const candidateInfo = ((metadata[scope] ??= {})[candidate] ??= {
      id: candidate, number: row.number, name: row.ballot, party: row.party, elected: false,
    });
    candidateInfo.elected ||= row.elected;
    addTo(local[5], candidate, row.votes);
    addTo(((contestSums[scope] ??= {})[row.round] ??= {}), candidate, row.votes);
    if (row.uf !== 'ZZ') {
      addTo(ufs[row.uf][office][row.round][5], candidate, row.votes);
      if (row.office === 1) addTo(domestic[row.round][5], candidate, row.votes);
    }
  }
  audit.snapshots = [...new Set(localVotes.map(row => row.snapshot))].sort();
  for (const row of localCounts) {
    const key = resultKey(row);
    const votes = Object.values(municipal.get(key)[5]).reduce((a, b) => a + b, 0);
    if (votes !== row.valid) audit.discrepancies.push({ key, candidateVotes: votes, valid: row.valid });
  }
  const races = {};
  for (const [scope, scopeRounds] of Object.entries(contestSums)) {
    const rounds = Object.keys(scopeRounds).map(Number);
    const rank = round => Object.keys(scopeRounds[round] ?? {})
      .sort((a, b) => scopeRounds[round][b] - scopeRounds[round][a] || a.localeCompare(b));
    const pair = rank(rounds.at(-1)).slice(0, 2);
    races[scope] = { rounds, pair, candidates: [...new Set(rounds.flatMap(rank))].map(id => metadata[scope][id]) };
    audit.official[scope] = { totals: scopeCounts[scope], votes: scopeRounds };
  }

  const tables = {};
  tables.votes = localVotes.filter(row => row.uf !== 'ZZ').map(row => ({
    year, office: officeName[row.office], round: row.round, id: row.id,
    candidate: `${year}-${raceKey(row)}-${row.candidate}`, votes: row.votes,
  }));
  tables.counts = localCounts.filter(row => row.uf !== 'ZZ').map(row => ({
    year, office: officeName[row.office], round: row.round, id: row.id,
    ...Object.fromEntries(countKeys.map(key => [key, row[key]])),
  }));
  tables.candidates = Object.entries(races).flatMap(([scope, race]) => race.candidates.map(c => ({
    id: `${year}-${scope}-${c.id}`, name: c.name, party: c.party,
  })));
  return { year, races, states, ufs, domestic, locations, audit, tables };
}
