"""Extrai as tabelas publicadas do Radar IDHM e do Atlas da Violência.

Uso: python data/prepare-reference.py CAMINHO_DOS_BRUTOS
Dependências opcionais para atualizar a referência: pypdf e rdata.
"""
import json
import re
import sys
from pathlib import Path

import rdata
from pypdf import PdfReader

STATES = dict(line.split(":", 1) for line in """Acre:AC
Alagoas:AL
Amapá:AP
Amazonas:AM
Bahia:BA
Ceará:CE
Distrito Federal:DF
Espírito Santo:ES
Goiás:GO
Maranhão:MA
Mato Grosso:MT
Mato Grosso do Sul:MS
Minas Gerais:MG
Pará:PA
Paraíba:PB
Paraná:PR
Pernambuco:PE
Piauí:PI
Rio de Janeiro:RJ
Rio Grande do Norte:RN
Rio Grande do Sul:RS
Rondônia:RO
Roraima:RR
Santa Catarina:SC
São Paulo:SP
Sergipe:SE
Tocantins:TO
Brasil:BR""".splitlines())


def observation(location, year, metric, value):
    return {"id": location, "year": year, "metric": metric, "value": value}


def radar(path):
    document = PdfReader(path)
    table = document.pages[124].extract_text()
    page_brazil = document.pages[39].extract_text()
    rows = []
    for line in table.splitlines():
        fields = line.split()
        if len(fields) < 15 or not fields[0].isdecimal():
            continue
        name = " ".join(fields[1:-13])
        if name in STATES:
            rows.extend(observation(STATES[name], 2012 + i, "idhm", float(value))
                        for i, value in enumerate(fields[-13:]))
    rows.extend(observation("BR", int(year), "idhm", float(value.replace(",", ".")))
                for year, value in re.findall(r"^((?:201[2-9]|202[0-4]))\s+(?:0,\d{3}\s+){3}(0,\d{3})", page_brazil, re.M))
    assert len(rows) == 28 * 13, f"Cobertura inesperada do Radar IDHM: {len(rows)}"
    return rows


def homicides(path):
    table = PdfReader(path).pages[15].extract_text()
    rows = []
    for line in table.splitlines():
        fields = line.split()
        if len(fields) < 15:
            continue
        name = " ".join(fields[:-14])
        if name in STATES:
            values = fields[-14:-3]
            rows.extend(observation(STATES[name], 2014 + i, "homicides", float(value.replace(",", ".")))
                        for i, value in enumerate(values))
    assert len(rows) == 28 * 11, f"Cobertura inesperada de homicídios: {len(rows)}"
    return rows


def municipal_atlas(path):
    data = rdata.read_rda(path)["pnud_min"]
    rows = data.loc[data["ano"].astype(str) == "2010", ["muni_id", "idhm"]].dropna()
    assert len(rows) == 5562, f"Cobertura inesperada de IDHM municipal: {len(rows)}"
    return [observation(str(location), 2010, "idhmMunicipal", round(float(value), 3))
            for location, value in rows.itertuples(index=False, name=None)]


raw = Path(sys.argv[1])
target = Path(__file__).parent / "reference" / "series.json"
data = [*radar(raw / "radar.pdf"), *homicides(raw / "violencia.pdf"), *municipal_atlas(raw / "pnud-min.rda")]
target.parent.mkdir(exist_ok=True)
target.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
print(f"{len(data)} observações de referência gravadas.")
