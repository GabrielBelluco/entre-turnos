import { defineConfig } from 'vite';

const offline = process.env.ENTRE_TURNOS_OFFLINE === '1';

export default defineConfig({
  base: './',
  ...(offline ? {
    publicDir: false,
    build: { cssCodeSplit: false, rollupOptions: { output: { inlineDynamicImports: true } } },
  } : {}),
});
