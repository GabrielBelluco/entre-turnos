import { createRoot } from 'react-dom/client'
import { useEffect, useState } from 'react'
import { ArrowUpRight, BookOpen, ChartNoAxesCombined, Map as MapIcon } from 'lucide-react'
import Atlas from './Atlas'
import Timeline from './Timeline'
import { dataUrl, metrics, type Context, type Manifest, type Page } from './model'
import { useResource } from './useResource'
import './styles.css'

const emptyContext: Context = { indicators: [], terms: [] }
const nav = [
  { id: 'atlas', label: 'Atlas eleitoral', icon: MapIcon },
  { id: 'evolucao', label: 'Evolução', icon: ChartNoAxesCombined },
  { id: 'metodologia', label: 'Metodologia', icon: BookOpen },
] as const
const getPage = (): Page => {
  const page = location.hash.slice(1)
  return page === 'evolucao' || page === 'metodologia' ? page : 'atlas'
}

const introductions = {
  atlas: { title: 'O voto no território.', text: 'Explore eleições para presidente e governador, compare os turnos e cruze a votação com indicadores de cada território.' },
  evolucao: { title: 'O Brasil no tempo.', text: 'Compare a trajetória dos indicadores estaduais e acompanhe as datas dos mandatos federais e estaduais.' },
  metodologia: { title: 'Por trás do mapa.', text: 'Consulte as fontes, os critérios de comparação e as fórmulas usadas em cada visualização.' },
}

function Methodology({ manifest }: { manifest: Manifest }) {
  return <section className="method-grid" aria-label="Metodologia">
    <article className="surface method-card">
      <h2>Apuração, votos e margem</h2>
      <p>Somamos os arquivos de votação nominal e detalhe da apuração por município, turno e cargo. O percentual de um candidato divide seus votos nominais válidos por todos os votos válidos do turno. Comparecimento divide o total de votantes por eleitores aptos.</p>
      <p>A margem subtrai o percentual do segundo finalista do percentual do primeiro finalista, na ordem do resultado final da disputa. A mudança é a margem do segundo turno menos a do primeiro. Uma inversão exige sinais opostos nos dois turnos. No comparativo nacional por UF para governador, a margem do primeiro turno usa os dois candidatos mais votados em cada UF naquele turno.</p>
      <p>As visualizações nacionais somam os votos no território brasileiro. A conferência do total oficial de presidente inclui os votos do exterior.</p>
      <div className="source-list">{manifest.years.map(year => <a href={`https://dadosabertos.tse.jus.br/dataset/resultados-${year}`} target="_blank" rel="noreferrer" key={year}>Resultados TSE {year} <ArrowUpRight size={14} /></a>)}</div>
    </article>
    <article className="surface method-card">
      <h2>O que os indicadores medem</h2>
      <p>Os filtros estaduais usam o último ano de referência comum anterior à eleição. Alfabetização e IDHM municipal contextualizam a eleição de 2026, com seus anos originais. Dado faltante aparece como “Sem dados”.</p>
      <p>Homicídios registrados medem óbitos por causas incluídas no Atlas da Violência, na UF de residência. As comparações descrevem resultados agregados e ficam no nível do território.</p>
      <div className="source-list">{Object.values(metrics).map(item => <a href={item.url} target="_blank" rel="noreferrer" key={item.name}>{item.name} · {item.source} <ArrowUpRight size={14} /></a>)}</div>
    </article>
    <article className="surface method-card">
      <h2>Municípios e fronteiras</h2>
      <p>A malha do IBGE de 2025 é a referência visual comum. Os códigos oficiais do TSE e do IBGE ligam os resultados à geometria. Localidades criadas após o pleito podem aparecer sem resultado naquele ano.</p>
      <div className="source-list">
        <a href="https://dadosabertos.tse.jus.br/dataset/codigos-oficiais-de-uf-e-municipios-segundo-o-tse-e-o-ibge" target="_blank" rel="noreferrer">Correspondência de códigos TSE–IBGE <ArrowUpRight size={14} /></a>
        <a href="https://www.ibge.gov.br/geociencias/organizacao-do-territorio/malhas-territoriais/15774-malhas.html" target="_blank" rel="noreferrer">Malha municipal do IBGE <ArrowUpRight size={14} /></a>
      </div>
    </article>
    <article className="surface method-card">
      <h2>Mandatos e anos eleitorais</h2>
      <p>Os marcadores indicam a data do primeiro turno de cada eleição geral. As faixas são intervalos de exercício, com as datas e a fonte disponíveis ao clicar. As medições anuais são apresentadas ao meio do ano para situar a observação no gráfico.</p>
      <div className="source-list"><a href="https://www.gov.br/casacivil/pt-br/acesso-a-informacao/receitas-e-despesas/acervos-de-mandatos-presidenciais-encerrados" target="_blank" rel="noreferrer">Acervos de mandatos presidenciais <ArrowUpRight size={14} /></a></div>
    </article>
  </section>
}

function App() {
  const manifest = useResource<Manifest>(dataUrl('index.json'))
  const context = useResource<Context>(dataUrl('context.json'))
  const [page, setPage] = useState<Page>(getPage)
  useEffect(() => {
    const onHash = () => { setPage(getPage()); window.scrollTo(0, 0) }
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  const intro = introductions[page]
  return <>
    <a href="#conteudo" className="skip-link" onClick={event => { event.preventDefault(); document.getElementById('conteudo')?.focus() }}>Pular para conteúdo</a>
    <header className="site-header"><div className="shell header-content">
      <a href="#atlas" className="brand"><i><MapIcon size={20} strokeWidth={1.9} /></i><span>Entre Turnos</span></a>
      <nav aria-label="Navegação principal">{nav.map(item => <a href={`#${item.id}`} aria-current={item.id === page ? 'page' : undefined} key={item.id}><item.icon size={16} />{item.label}</a>)}</nav>
      <a href="https://dadosabertos.tse.jus.br/" target="_blank" rel="noreferrer" className="header-source">Dados abertos <ArrowUpRight size={14} /></a>
    </div></header>
    <main className="shell" id="conteudo" tabIndex={-1}>
      <section className="intro">
        <div>
          <p className="eyebrow"><span /> ATLAS ELEITORAL DO BRASIL</p>
          <h1>{intro.title}</h1>
          <p>{intro.text}</p>
        </div>
        <div className="intro-years"><span>ELEIÇÕES GERAIS</span><strong>2018 <i /> 2026</strong><small>Brasil · 27 unidades da Federação</small></div>
      </section>
      {manifest?.error && <div className="banner" role="alert">A base eleitoral está indisponível. Verifique os arquivos de dados do atlas.</div>}
      {!manifest && <div className="surface loading" role="status">Carregando dados eleitorais…</div>}
      {manifest?.data && <>
        {context?.error && page !== 'metodologia' && <div className="banner" role="alert">Os indicadores estão indisponíveis no momento.</div>}
        <div hidden={page !== 'atlas'}><Atlas manifest={manifest.data} context={context?.data ?? emptyContext} /></div>
        {page === 'evolucao' && (context?.data ? <Timeline manifest={manifest.data} context={context.data} /> : !context?.error && <div className="surface loading" role="status">Carregando séries anuais…</div>)}
        {page === 'metodologia' && <Methodology manifest={manifest.data} />}
      </>}
    </main>
    <footer className="site-footer"><div className="shell"><a href="#atlas" className="brand"><i><MapIcon size={17} /></i> Entre Turnos</a><span>Dados públicos · TSE, IBGE, PNUD, FJP e Ipea</span><a href="#metodologia">Fontes e metodologia <ArrowUpRight size={15} /></a></div></footer>
  </>
}

createRoot(document.getElementById('root')!).render(<App />)
