import { useEffect, useRef, useState } from 'react'
import maplibregl, { type ExpressionSpecification, type GeoJSONSource, type LngLatBoundsLike, type Map as MapLibreMap } from 'maplibre-gl'
import type { FeatureCollection, Geometry } from 'geojson'
import { MapPinned } from 'lucide-react'
import 'maplibre-gl/dist/maplibre-gl.css'
import { useResource } from './useResource'
import { dataUrl } from './model'

type Shape = FeatureCollection<Geometry, { id: string; name: string }>
const empty: Shape = { type: 'FeatureCollection', features: [] }
const colors = { land: '#e8e5d9', line: '#f9f7f0', selected: '#173b35', outside: '#eeebe2' }
const brazil: LngLatBoundsLike = [[-74.5, -34], [-33.3, 5.6]]

function findBounds(shapes: Shape): LngLatBoundsLike | undefined {
  const bounds = new maplibregl.LngLatBounds()
  function collect(value: unknown) {
    if (!Array.isArray(value)) return
    if (typeof value[0] === 'number') bounds.extend([value[0], value[1]])
    else value.forEach(collect)
  }
  for (const feature of shapes.features) {
    if ('coordinates' in feature.geometry) collect(feature.geometry.coordinates)
  }
  return bounds.isEmpty() ? undefined : bounds
}

export default function TerritoryMap({ scope, selected, fills, onSelect, onHover }: {
  scope: string
  selected: string
  fills: Map<string, string>
  onSelect: (id: string) => void
  onHover: (id: string) => string
}) {
  const shapes = useResource<Shape>(dataUrl(`geo-${scope}.geojson`))
  const base = useResource<Shape>(dataUrl('geo-BR.geojson'))
  const container = useRef<HTMLDivElement>(null)
  const map = useRef<MapLibreMap | null>(null)
  const handlers = useRef({ onSelect, onHover })
  const [ready, setReady] = useState(false)
  const [unavailable, setUnavailable] = useState(false)
  handlers.current = { onSelect, onHover }

  useEffect(() => {
    let chart: MapLibreMap
    if (!container.current) return
    try {
      chart = new maplibregl.Map({
        container: container.current, attributionControl: false, dragRotate: false, touchPitch: false,
        scrollZoom: false, minZoom: 2.2, maxZoom: 13, bounds: brazil, fitBoundsOptions: { padding: 24 },
        style: {
          version: 8, sources: {}, layers: [
            { id: 'ocean', type: 'background', paint: { 'background-color': '#eaece5' } },
          ],
        },
      })
    } catch {
      setUnavailable(true)
      return
    }
    map.current = chart
    chart.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')
    chart.addControl(new maplibregl.ScaleControl({ maxWidth: 75, unit: 'metric' }), 'bottom-left')
    const tooltip = new maplibregl.Popup({ closeButton: false, closeOnClick: false, offset: 11, maxWidth: '260px' })
    chart.on('load', () => {
      chart.addSource('outline', { type: 'geojson', data: empty })
      chart.addSource('areas', { type: 'geojson', data: empty })
      chart.addLayer({ id: 'outline', type: 'fill', source: 'outline', paint: { 'fill-color': colors.outside } })
      chart.addLayer({ id: 'outline-border', type: 'line', source: 'outline', paint: { 'line-color': '#d4d9cf', 'line-width': 0.65 } })
      chart.addLayer({ id: 'areas', type: 'fill', source: 'areas', paint: { 'fill-color': colors.land, 'fill-opacity': 0.96 } })
      chart.addLayer({ id: 'borders', type: 'line', source: 'areas', paint: { 'line-color': colors.line, 'line-width': 0.65 } })
      chart.addLayer({
        id: 'selected', type: 'line', source: 'areas',
        filter: ['==', ['id'], ''], paint: { 'line-color': colors.selected, 'line-width': 2.4 },
      })
      chart.on('click', 'areas', event => {
        const id = event.features?.[0]?.id
        if (id !== undefined) handlers.current.onSelect(String(id))
      })
      chart.on('mousemove', 'areas', event => {
        const id = event.features?.[0]?.id
        if (id === undefined) return
        chart.getCanvas().style.cursor = 'pointer'
        tooltip.setLngLat(event.lngLat).setText(handlers.current.onHover(String(id))).addTo(chart)
      })
      chart.on('mouseleave', 'areas', () => {
        chart.getCanvas().style.cursor = ''
        tooltip.remove()
      })
      setReady(true)
    })
    const resize = new ResizeObserver(() => chart.resize())
    resize.observe(container.current)
    return () => { resize.disconnect(); tooltip.remove(); chart.remove(); map.current = null }
  }, [])

  useEffect(() => {
    if (!ready || !map.current) return
    ;(map.current.getSource('outline') as GeoJSONSource).setData(base?.data ?? empty)
  }, [base, ready])

  useEffect(() => {
    if (!ready || !map.current) return
    ;(map.current.getSource('areas') as GeoJSONSource).setData(shapes?.data ?? empty)
    if (shapes?.data) {
      const bounds = scope === 'BR' ? brazil : findBounds(shapes.data)
      if (bounds) map.current.fitBounds(bounds, { padding: 33, duration: 350, maxZoom: 8 })
    }
  }, [scope, shapes, ready])

  useEffect(() => {
    if (!ready || !map.current) return
    const color: ExpressionSpecification | string = fills.size
      ? ['match', ['id'], ...Array.from(fills).flat(), colors.land] as ExpressionSpecification : colors.land
    map.current.setPaintProperty('areas', 'fill-color', color)
    map.current.setFilter('selected', ['==', ['id'], selected || ''])
  }, [fills, ready, selected])

  const status = unavailable ? 'O mapa precisa de WebGL. Explore os mesmos resultados na tabela.'
    : shapes?.error ? 'Falha ao carregar a malha. Os resultados estão disponíveis na tabela.'
    : !ready || !shapes ? 'Carregando mapa…' : ''

  return <div className="map-stage">
    <div className="map-canvas" ref={container} aria-label="Mapa eleitoral interativo" />
    {status && <div className="map-notice" role="status"><MapPinned size={22} />{status}</div>}
    {!status && <a className="map-credit" href="https://www.ibge.gov.br/geociencias/organizacao-do-territorio/malhas-territoriais/15774-malhas.html" target="_blank" rel="noreferrer">Malha IBGE 2025</a>}
  </div>
}
