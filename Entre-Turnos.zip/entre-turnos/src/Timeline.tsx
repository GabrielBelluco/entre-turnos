import { lazy, Suspense, useState, type CSSProperties } from 'react'
import { ArrowUpRight, CalendarRange } from 'lucide-react'
import type { EChartsCoreOption } from 'echarts/core'
import { metrics, metricValue, type Context, type Manifest, type Metric, type Term } from './model'

const Chart = lazy(() => import('./Chart'))
const firstYear = 2014
const lastYear = 2026
const start = Date.UTC(firstYear, 0, 1)
const end = Date.UTC(lastYear + 1, 0, 1)
const day = (value: string) => Date.parse(`${value}T00:00:00Z`)
const position = (value: number) => 100 * Math.max(0, Math.min(1, (value - start) / (end - start)))
const dateFormat = new Intl.DateTimeFormat('pt-BR', { timeZone: 'UTC' })
const displayDate = (value: string) => dateFormat.format(day(value))
const stateColors = ['#267363', '#bc563b']

function TermBand({ name, terms, choose }: { name: string; terms: Term[]; choose: (term: Term) => void }) {
  return <div className="term-row">
    <span className="band-label">{name}</span>
    <div className="band-track" aria-label={`Mandatos ${name}`}>
      {terms.map((term, i) => {
        const left = position(day(term.start))
        const width = position(term.end ? day(term.end) : end) - left
        if (width <= 0) return null
        return <button key={term.start} type="button" className={`term term-${i % 4}`}
          style={{ left: `${left}%`, width: `${width}%` }}
          title={`${term.name} · ${displayDate(term.start)} · ${term.end ? displayDate(term.end) : 'em exercício no recorte'}`}
          aria-label={`${term.name}, de ${displayDate(term.start)} a ${term.end ? displayDate(term.end) : 'data de corte'}`}
          onClick={() => choose(term)}>{term.name}</button>
      })}
      {!terms.length && <span className="term-missing">Cronologia indisponível</span>}
    </div>
  </div>
}

export default function Timeline({ manifest, context }: { manifest: Manifest; context: Context }) {
  const [metric, setMetric] = useState<Metric>('homicides')
  const [primary, setPrimary] = useState('ES')
  const [secondary, setSecondary] = useState('SP')
  const [term, setTerm] = useState<Term>()
  const active = [primary, secondary].filter((value, index, all) => value && all.indexOf(value) === index)
  const ufs = Object.entries(manifest.ufs).sort((a, b) => a[1].name.localeCompare(b[1].name, 'pt-BR'))
  const series = active.map((id, index) => {
    const observations = context.indicators.filter(row => row.id === id && row.metric === metric && row.year >= firstYear)
    const observationsByYear = new Map(observations.map(row => [row.year, row.value]))
    const last = Math.max(firstYear, ...observations.map(row => row.year))
    return {
      name: manifest.ufs[id]?.name ?? id, color: stateColors[index], observations,
      data: Array.from({ length: 1 + last - firstYear }, (_, i) => {
        const year = firstYear + i
        return [Date.UTC(year, 6, 1), observationsByYear.get(year) ?? null]
      }),
    }
  })
  const latest = Math.max(0, ...series.flatMap(line => line.observations.map(row => row.year)))
  const option: EChartsCoreOption = {
    color: stateColors,
    animation: false,
    grid: { left: 58, right: 16, top: 25, bottom: 28 },
    tooltip: {
      trigger: 'axis', renderMode: 'richText',
      formatter: (items: Array<{ name: string; value: [number, number | null]; seriesName: string }>) =>
        items.length ? [
          new Date(items[0].value[0]).getUTCFullYear(),
          ...items.map(item => `${item.seriesName}  ${item.value[1] === null ? 'Sem dado' : metricValue(metric, item.value[1])}`),
        ].join('\n') : '',
    },
    xAxis: { type: 'time', min: start, max: end, splitNumber: 8, axisLabel: { formatter: '{yyyy}', hideOverlap: true }, splitLine: { show: false } },
    yAxis: { type: 'value', scale: true, axisLabel: { formatter: (value: number) => metricValue(metric, value) }, splitLine: { lineStyle: { color: '#e6e4da' } } },
    series: series.map((line, index) => ({
      type: 'line', name: line.name, data: line.data, lineStyle: { width: 3 }, symbolSize: 8, connectNulls: false,
      markLine: index === 0 ? {
        symbol: 'none', label: { show: false }, silent: true, lineStyle: { color: '#97a49a', width: 1, opacity: 0.6 },
        data: [{ xAxis: Date.UTC(2014, 9, 5) }, { xAxis: Date.UTC(2018, 9, 7) }, { xAxis: Date.UTC(2022, 9, 2) }, { xAxis: Date.UTC(2026, 9, 4) }],
      } : undefined,
    })),
  }
  const federal = context.terms.filter(item => item.id === 'BR')
  return <div className="timeline-page">
    <section className="filter-bar" aria-label="Filtros da evolução">
      <div className="filter-heading"><CalendarRange size={18} /><span>Comparar trajetórias</span></div>
      <label>Indicador<select value={metric} onChange={event => setMetric(event.target.value as Metric)}>
        {Object.entries(metrics).filter(([, value]) => !value.municipal).map(([id, value]) => <option value={id} key={id}>{value.name}</option>)}
      </select></label>
      <label>Primeira UF<select value={primary} onChange={event => { setPrimary(event.target.value); setTerm(undefined) }}>
        {ufs.map(([id, value]) => <option value={id} key={id}>{value.name}</option>)}
      </select></label>
      <label>Segunda UF<select value={secondary} onChange={event => { setSecondary(event.target.value); setTerm(undefined) }}>
        <option value="">Uma UF</option>
        {ufs.filter(([id]) => id !== primary).map(([id, value]) => <option value={id} key={id}>{value.name}</option>)}
      </select></label>
    </section>
    <section className="surface timeline-card">
      <div className="section-head"><div>
        <p className="label">SÉRIE ANUAL {latest ? `· ${firstYear}–${latest}` : ''}</p>
        <h2>{metrics[metric].name}</h2><p className="subtle">{metrics[metric].unit}</p>
      </div><a className="text-button source-link" href={metrics[metric].url} target="_blank" rel="noreferrer">{metrics[metric].source} <ArrowUpRight size={15} /></a></div>
      <div className="series-key">{series.map(line => <span key={line.name}><i style={{ '--dot': line.color } as CSSProperties} />{line.name}</span>)}<span><i className="election-key" /> Eleição geral</span></div>
      <Suspense fallback={<div className="chart-host" />}><Chart option={option} label={`Série de ${metrics[metric].name} para ${series.map(line => line.name).join(' e ')}`} /></Suspense>
      <div className="bands">
        <TermBand name="Presidência" terms={federal} choose={setTerm} />
        {active.map(id => <TermBand name={id} terms={context.terms.filter(item => item.id === id)} choose={setTerm} key={id} />)}
        <div className="term-row axis-row"><span /><div className="band-axis">{[2014, 2016, 2018, 2020, 2022, 2024, 2026].map(year => <span key={year} style={{ left: `${position(Date.UTC(year, 0, 1))}%` }}>{year}</span>)}</div></div>
      </div>
      {term && <div className="term-detail" role="status"><div><strong>{term.name}</strong><span>{term.end ? `${displayDate(term.start)} a ${displayDate(term.end)}` : `Desde ${displayDate(term.start)} · em exercício na data de corte`}{term.note ? ` · ${term.note}` : ''}</span></div><a className="text-button" target="_blank" rel="noreferrer" href={term.source}>Fonte do mandato <ArrowUpRight size={15} /></a></div>}
      <p className="subtle timeline-note">As faixas indicam quem exerceu o cargo em cada período. A linha mostra medições anuais e descreve a evolução observada.</p>
    </section>
    <section className="surface table-card">
      <h2>Consultar valores anuais</h2>
      <div className="table-scroll"><table><thead><tr><th scope="col">Ano</th>{series.map(line => <th scope="col" key={line.name}>{line.name}</th>)}</tr></thead>
        <tbody>{Array.from({ length: Math.max(0, latest - firstYear + 1) }, (_, i) => latest - i).map(year => <tr key={year}>
          <th scope="row">{year}</th>{series.map(line => {
            const value = line.observations.find(row => row.year === year)?.value
            return <td key={line.name}>{value === undefined ? '—' : metricValue(metric, value)}</td>
          })}
        </tr>)}</tbody>
      </table></div>
    </section>
  </div>
}
