import { useEffect, useState } from 'react'

const pending = new Map<string, Promise<unknown>>()

async function readEmbedded<T>(encoded: string): Promise<T> {
  const bytes = Uint8Array.from(atob(encoded), character => character.charCodeAt(0))
  return new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).json()
}

function load<T>(url: string) {
  if (!pending.has(url)) {
    const data = (window as Window & { entreTurnosData?: Record<string, string> }).entreTurnosData
    const embedded = data?.[url.split('/').at(-1) ?? '']
    const request = embedded ? readEmbedded(embedded) : fetch(url)
      .then(response => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`)
        return response.json()
      })
    pending.set(url, request.catch(error => {
        pending.delete(url)
        throw error
      }))
  }
  return pending.get(url) as Promise<T>
}

export function useResource<T>(url: string) {
  const [state, setState] = useState<{ url: string; data?: T; error?: boolean }>()
  useEffect(() => {
    let active = true
    load<T>(url).then(
      data => { if (active) setState({ url, data }) },
      () => { if (active) setState({ url, error: true }) },
    )
    return () => { active = false }
  }, [url])
  return state?.url === url ? state : undefined
}
