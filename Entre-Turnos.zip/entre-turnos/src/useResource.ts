import { useEffect, useState } from 'react'

const pending = new Map<string, Promise<unknown>>()

function load<T>(url: string) {
  if (!pending.has(url)) {
    pending.set(url, fetch(url)
      .then(response => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`)
        return response.json()
      })
      .catch(error => {
        pending.delete(url)
        throw error
      }))
  }
  return pending.get(url) as Promise<T>
}

export function useResource<T>(url: string) {
  const [state, setState] = useState<{ url: string; data?: T; error?: boolean }>()
  useEffect(() => {
    let active = true
    load<T>(url).then(
      data => { if (active) setState({ url, data }) },
      () => { if (active) setState({ url, error: true }) },
    )
    return () => { active = false }
  }, [url])
  return state?.url === url ? state : undefined
}
