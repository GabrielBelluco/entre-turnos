import { lazy, Suspense, useEffect, useMemo, useState } from 'react'
import { ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, Filter, MapPin, Search } from 'lucide-react'
import type { EChartsCoreOption } from 'echarts/core'
import {
  dataUrl, decimal, integer, inversion, margin, metrics, metricValue, normalize, officeNames, percent,
  points, raceFor, referenceYear, share, topMargin,
  type Context, type Counts, type Manifest, type Metric, type Mode, type Office, type Race, type Results, type Round,
} from './model'
import { useResource } from './useResource'

const TerritoryMap = lazy(() => import('./TerritoryMap'))
const Chart = lazy(() => import('./Chart'))
const mapColors = ['#a84229', '#d37a56', '#ecd5b8', '#c2d8c7', '#62a28b', '#256d5d']
const noData = '#dadbd1'
const excluded = '#eeece4'

type State = { year: number; office: Office; uf: string; selected: string; mode: Mode }
type Place = {
  id: string; name: string; race?: Race; first?: Counts; second?: Counts; current?: Counts;
  m1: number | null; m2: number | null; change: number | null; value: number | null;
  index?: number; included: boolean
}

function paint(value: number | null, nationalGovernor: boolean) {
  if (value === null) return noData
  if (nationalGovernor) return value < 5 ? '#dfe8cc' : value < 15 ? '#9fbea5' : value < 25 ? '#5a9882' : '#256d5d'
  if (value < -15) return mapColors[0]
  if (value < -5) return mapColors[1]
  if (value < 0) return mapColors[2]
  if (value === 0) return '#e9e2c9'
  if (value <= 5) return mapColors[3]
  if (value <= 15) return mapColors[4]
  return mapColors[5]
}

function readState(manifest: Manifest): State {
  const params = new URLSearchParams(location.search)
  const requestedYear = Number(params.get('ano'))
  const requestedUf = params.get('uf')?.toUpperCase() ?? ''
  const year = manifest.years.includes(requestedYear) ? requestedYear : manifest.years.at(-1)!
  const uf = manifest.ufs[requestedUf] ? requestedUf : ''
  const requestedMode = params.get('modo')
  const office = params.get('cargo') === 'governador' ? 'G' : 'P'
  const contest = raceFor(manifest, year, office, uf)
  const mode = uf && contest && !contest.rounds.includes(2) ? '1'
    : requestedMode === '1' || requestedMode === '2' ? requestedMode : 'shift'
  const place = params.get('local') ?? ''
  return {
    year, uf, office, mode,
    selected: manifest.ufs[place] || manifest.locations[place]?.uf === uf ? place : '',
  }
}

function CandidateBars({ counts, race, year }: { counts: Counts; race: Race; year: number }) {
  const choices = race.candidates
    .filter(candidate => Object.hasOwn(counts[5], candidate.id))
    .sort((a, b) => counts[5][b.id] - counts[5][a.id])
  const [all, setAll] = useState(false)
  return <div className="candidate-list">
    {choices.slice(0, all ? undefined : 3).map(candidate => {
      const pct = share(counts[5][candidate.id], counts[2])
      const color = candidate.id === race.pair[0] ? '#3b8d76' : candidate.id === race.pair[1] ? '#cc7759' : '#a9a594'
      return <div className="candidate" key={candidate.id} title={`${integer(counts[5][candidate.id])} votos • eleição de ${year}`}>
        <div className="candidate-label"><span>{candidate.name} <small>{candidate.party}</small></span><strong>{percent(pct)}</strong></div>
        <div className="candidate-track"><span style={{ width: `${pct ?? 0}%`, background: color }} /></div>
        <small>{integer(counts[5][candidate.id])} votos</small>
      </div>
    })}
    {choices.length > 3 && <button className="text-button" onClick={() => setAll(!all)}>{all ? 'Ver menos' : 'Ver todos os candidatos'}</button>}
  </div>
}

function Detail({ place, state, national, open, metric }: {
  place?: Place; state: State; national: boolean; open: (id: string) => void; metric: Metric | '';
}) {
  if (!place) return <aside className="detail-panel">
    <p className="label"><MapPin size={14} /> LEITURA DO MAPA</p>
    <h2>{national ? 'Escolha um estado' : 'Escolha um município'}</h2>
    <p className="detail-note">{national && state.office === 'G'
      ? 'Cada governo estadual tem sua própria disputa. Selecione uma UF para comparar os candidatos e explorar seus municípios.'
      : 'Clique no mapa ou selecione uma localidade na tabela para ver a votação.'}</p>
  </aside>
  const flip = inversion(place.m1, place.m2)
  const race = place.race
  const turns = state.mode === 'shift' ? ([1, 2] as const) : ([Number(state.mode)] as Round[])
  const comparison = state.mode === 'shift' && place.change !== null
  const base = place.current ?? place.second ?? place.first
  return <aside className="detail-panel" aria-live="polite">
    <p className="label"><MapPin size={14} /> {place.id === 'BR' ? 'SOMA DAS UFs' : national ? place.id : state.uf}</p>
    <h2>{place.name}</h2>
    <p className="detail-note">{officeNames[state.office]} · {state.year}
      {state.mode === 'shift' && race?.candidates[0] && race.pair.length > 1 && <>
        <br />Margem de {race.candidates.find(c => c.id === race.pair[0])?.name} sobre {race.candidates.find(c => c.id === race.pair[1])?.name}.
      </>}
    </p>
    {comparison ? <div className="detail-shift">
      {place.change! >= 0 ? <ArrowUpRight size={23} /> : <ArrowDownRight size={23} />}
      <div><strong>{points(place.change, true)}</strong><span>{flip ? 'A liderança entre os finalistas se inverteu' : 'Mudança de margem entre turnos'}</span></div>
    </div> : base && <div className="detail-shift"><div><strong>{integer(base[2])}</strong><span>Votos válidos {base === place.second ? 'no 2º turno' : 'no 1º turno'}</span></div></div>}
    {metric && place.index !== undefined && <p className="detail-metric">{metrics[metric].name} <strong>{metricValue(metric, place.index)}</strong></p>}
    {turns.map(turn => {
      const data = turn === 1 ? place.first : place.second
      return <div className="turn-block" key={`${place.id}-${turn}`}>
        <div className="turn-label"><strong>{turn}º turno</strong>{data && <span>{percent(share(data[1], data[0]))} de comparecimento</span>}</div>
        {data && race ? <CandidateBars counts={data} race={race} year={state.year} />
          : <p className="detail-note">{turn === 2 && !race?.rounds.includes(2) ? 'Sem segundo turno.' : 'Sem dados para este recorte.'}</p>}
      </div>
    })}
    {national && place.id !== 'BR' && <button className="detail-open" onClick={() => open(place.id)}>Explorar municípios <ArrowRight size={16} /></button>}
  </aside>
}

export default function Atlas({ manifest, context }: { manifest: Manifest; context: Context }) {
  const [state, setState] = useState(() => readState(manifest))
  const [metric, setMetric] = useState<Metric | ''>('')
  const [range, setRange] = useState({ min: '', max: '' })
  const [query, setQuery] = useState('')
  const [chartType, setChartType] = useState<'turns' | 'context'>('turns')
  const [measure, setMeasure] = useState<'margin' | 'turnout'>('margin')
  const [candidate, setCandidate] = useState('')
  const [expanded, setExpanded] = useState(false)
  const scope = state.uf || 'BR'
  const national = scope === 'BR'
  const crossStateGovernor = national && state.office === 'G'
  const race = raceFor(manifest, state.year, state.office, scope)
  const result = useResource<Results>(dataUrl(`results-${state.year}-${scope}.json`))
  const observed = useMemo(() => national
    ? Object.keys(manifest.ufs)
    : Object.keys(manifest.locations).filter(id => manifest.locations[id].uf === scope),
  [manifest, national, scope])
  const activeMetric = metric && (!national === Boolean(metrics[metric].municipal)) && (national || state.year === 2026) ? metric : ''
  const metricYear = useMemo(() => activeMetric ? referenceYear(context.indicators, activeMetric, state.year, observed) : undefined,
    [activeMetric, context, observed, state.year])
  const indices = useMemo(() => new Map(context.indicators
    .filter(item => item.metric === activeMetric && item.year === metricYear).map(item => [item.id, item.value])),
  [activeMetric, context, metricYear])
  const nameOf = (id: string) => manifest.ufs[id]?.name ?? manifest.locations[id]?.name ?? id
  const rows = result?.data?.rows
  const views = observed.map((id): Place => {
    const contest = raceFor(manifest, state.year, state.office, national ? id : scope)
    const rounds = rows?.[id]?.[state.office]
    const first = rounds?.[1]
    const second = rounds?.[2]
    const m1 = margin(first, contest?.pair)
    const m2 = margin(second, contest?.pair)
    const change = m1 !== null && m2 !== null ? m2 - m1 : null
    const current = state.mode === '1' ? first : second
    const index = indices.get(id)
    const inRange = !activeMetric || (index !== undefined && (range.min === '' || index >= Number(range.min)) && (range.max === '' || index <= Number(range.max)))
    const value = state.mode === 'shift' ? change : crossStateGovernor ? topMargin(current) : state.mode === '1' ? m1 : m2
    return { id, name: nameOf(id), race: contest, first, second, current, m1, m2, change, value, index, included: inRange }
  })
  const around = views.filter(item => item.included)
  const selected = views.find(item => item.id === state.selected)
  const domestic = result?.data?.domestic
  const p1 = margin(domestic?.[1], race?.pair)
  const p2 = margin(domestic?.[2], race?.pair)
  const detail = selected ?? (national && state.office === 'P' && !activeMetric && domestic ? {
    id: 'BR', name: 'Brasil', race, first: domestic[1], second: domestic[2], current: domestic[state.mode === '1' ? 1 : 2],
    m1: p1, m2: p2, change: p1 !== null && p2 !== null ? p2 - p1 : null, value: null, included: true
  } : undefined)
  const tones = new Map(views.map(item => [item.id, item.included ? paint(item.value, crossStateGovernor && state.mode !== 'shift') : excluded]))
  const flipCount = around.filter(item => inversion(item.m1, item.m2)).length
  const observedCount = around.filter(item => item.value !== null).length
  const displayed = around.filter(item => normalize(item.name).includes(normalize(query.trim())))
    .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'))
  const stateList = Object.entries(manifest.ufs).sort((a, b) => a[1].name.localeCompare(b[1].name, 'pt-BR'))
  const scopeText = national ? 'Unidades da Federação' : manifest.ufs[scope].name

  function patch(next: Partial<State>) {
    setState(previous => {
      const proposed = { ...previous, ...next }
      const contest = raceFor(manifest, proposed.year, proposed.office, proposed.uf || 'BR')
      if (proposed.uf && contest && !contest.rounds.includes(2) && proposed.mode !== '1') proposed.mode = '1'
      return proposed
    })
  }

  useEffect(() => {
    const onPop = () => setState(readState(manifest))
    window.addEventListener('popstate', onPop)
    return () => window.removeEventListener('popstate', onPop)
  }, [manifest])

  useEffect(() => {
    if (location.protocol === 'file:') return
    const params = new URLSearchParams(location.search)
    params.set('ano', String(state.year))
    params.set('cargo', state.office === 'P' ? 'presidente' : 'governador')
    params.set('modo', state.mode)
    if (state.uf) params.set('uf', state.uf)
    else params.delete('uf')
    if (state.selected) params.set('local', state.selected)
    else params.delete('local')
    history.replaceState(null, '', `?${params}${location.hash}`)
  }, [state])

  function open(id: string) {
    setMetric('')
    setRange({ min: '', max: '' })
    setQuery('')
    setExpanded(false)
    patch({ uf: id, selected: '' })
  }

  const detailSelect = (id: string) => {
    if (around.some(item => item.id === id)) patch({ selected: id })
  }
  const changeMetric = (value: Metric | '') => {
    setMetric(value)
    setChartType(value ? 'context' : 'turns')
    setRange({ min: '', max: '' })
    patch({ selected: '' })
  }
  const compareContext = chartType === 'context' && activeMetric
  const selectedCandidate = race?.candidates.find(item => item.id === candidate && (state.mode !== '2' || race.pair.includes(item.id)))
    ?? race?.candidates.find(item => item.id === race?.pair[0])
  const axes = compareContext ? [
    `${metrics[activeMetric].name} · ${metricYear ?? '—'}`,
    state.office === 'P' ? `Votos de ${selectedCandidate?.name ?? 'candidato'} (%)` : measure === 'turnout' ? 'Comparecimento (%)' : 'Margem do 1º turno (p.p.)'
  ] : ['Margem no 1º turno (p.p.)', 'Margem no 2º turno (p.p.)']
  const pointsData = around.flatMap(item => {
    const counts = state.mode === '2' ? item.second : item.first
    const xv = compareContext ? item.index : item.m1
    const yv = !compareContext ? item.m2 : state.office === 'P'
      ? counts && selectedCandidate ? share(counts[5][selectedCandidate.id] ?? 0, counts[2]) : null
      : measure === 'turnout'
        ? counts ? share(counts[1], counts[0]) : null
        : topMargin(item.first)
    if (xv == null || yv == null) return []
    return [{
      id: item.id, name: item.name, value: [xv, yv, (item.second ?? item.first)?.[2] ?? 0],
      itemStyle: { color: item.id === state.selected ? '#c65538' : !compareContext && inversion(item.m1, item.m2) ? '#c65538' : '#438d78' },
    }]
  })
  const chartOption: EChartsCoreOption = {
    animation: false, grid: { left: 50, right: 24, top: 16, bottom: 47 },
    tooltip: { trigger: 'item', renderMode: 'richText', formatter: (data: { data: typeof pointsData[number] }) =>
      `${data.data.name}\n${decimal(data.data.value[0], activeMetric.startsWith('idhm') && compareContext ? 3 : 1)} · ${decimal(data.data.value[1])}\n${integer(data.data.value[2])} votos válidos` },
    xAxis: { name: axes[0], nameLocation: 'middle', nameGap: 27, type: 'value', scale: true, axisLabel: { color: '#56675d' }, splitLine: { lineStyle: { color: '#e9e7df' } } },
    yAxis: { type: 'value', scale: true, axisLabel: { color: '#56675d' }, splitLine: { lineStyle: { color: '#e9e7df' } } },
    series: [{ type: 'scatter', data: pointsData, symbolSize: (value: number[]) => Math.max(6, Math.min(26, 4 + Math.log10(Math.max(1, value[2])) ** 2 / 2.7)),
      markLine: compareContext ? undefined : { symbol: 'none', silent: true, label: { show: false },
        lineStyle: { color: '#7f8b80', opacity: 0.55 }, data: [{ xAxis: 0 }, { yAxis: 0 }] } }],
  }

  return <>
    <section className="filter-bar" aria-label="Filtros eleitorais">
      <div className="filter-heading"><Filter size={18} /> <span>Explorar resultados</span></div>
      <label>Ano eleitoral<select value={state.year} onChange={event => { setCandidate(''); patch({ year: Number(event.target.value) }) }}>
        {manifest.years.slice().reverse().map(year => <option key={year}>{year}</option>)}
      </select></label>
      <label>Cargo<select value={state.office} onChange={event => { setCandidate(''); patch({ office: event.target.value as Office }) }}>
        <option value="P">Presidente</option><option value="G">Governador</option>
      </select></label>
      <label>Território<select value={state.uf} onChange={event => open(event.target.value)}>
        <option value="">Brasil · por UF</option>
        {stateList.map(([uf, value]) => <option key={uf} value={uf}>{value.name} · {uf}</option>)}
      </select></label>
    </section>
    <div className="workspace-grid">
      <section className="surface map-card" aria-label="Mapa de resultados">
        <div className="map-head">
          <div>
            {!national && <button className="text-button back-link" onClick={() => open('')}><ArrowLeft size={14} /> Brasil</button>}
            <h2>{scopeText}</h2>
            <p>{officeNames[state.office]} · Eleições {state.year}</p>
          </div>
          <div className="mode-switch" aria-label="Turno">
            {([['shift', 'Mudança'], ['1', '1º turno'], ['2', '2º turno']] as const).map(([id, label]) =>
              <button key={id} className={state.mode === id ? 'active' : ''} type="button" aria-pressed={state.mode === id}
                disabled={Boolean(state.uf && race && !race.rounds.includes(2) && id !== '1')} onClick={() => patch({ mode: id })}>{label}</button>)}
          </div>
        </div>
        {state.uf && race && !race.rounds.includes(2) && <p className="inline-note">Sem segundo turno para este cargo nesta UF.</p>}
        {crossStateGovernor && state.mode === 'shift' && <p className="inline-note">A mudança aparece nas UFs em que houve segundo turno.</p>}
        <Suspense fallback={<div className="map-stage map-loading">Preparando mapa…</div>}>
          <TerritoryMap scope={scope} selected={state.selected} fills={tones} onSelect={detailSelect} onHover={id => {
            const item = views.find(view => view.id === id)
            if (!item || !item.included) return `${nameOf(id)} · fora do filtro`
            return `${nameOf(id)} · ${item.value == null ? 'Sem dados' : points(item.value, !crossStateGovernor || state.mode === 'shift')}`
          }} />
        </Suspense>
        <div className="map-legend">
          <div><strong>{state.mode === 'shift' ? 'Mudança da margem (p.p.)' : crossStateGovernor ? 'Margem da disputa (p.p.)' : 'Margem entre os finalistas (p.p.)'}</strong>
            <div className="color-key" style={crossStateGovernor && state.mode !== 'shift' ? { background: 'linear-gradient(90deg,#dfe8cc,#256d5d)' } : undefined} />
            <div className="color-ticks">{(crossStateGovernor && state.mode !== 'shift' ? ['0', '5', '15', '25+'] : ['−15', '−5', '0', '+5', '+15']).map(label => <span key={label}>{label}</span>)}</div>
          </div>
          <div className="map-coverage"><span><i style={{ background: noData }} /> Sem dados</span>{activeMetric && <span><i style={{ background: excluded }} /> Fora do filtro</span>}
            {result?.data && <span>{integer(observedCount)} {national ? 'UFs' : 'localidades'} com valor</span>}</div>
        </div>
      </section>
      <Detail key={`${state.year}-${state.office}-${scope}`} place={detail} state={state} national={national} open={open} metric={activeMetric} />
    </div>
    {result?.error && <div className="banner" role="alert">Falha ao carregar os resultados. Recarregue a página para tentar novamente.</div>}
    <div className="analysis-grid">
      <section className="surface analysis-controls">
        <p className="label"><Filter size={15} /> CONTEXTO</p>
        <h2>Filtrar por indicador</h2>
        <label>Indicador<select value={activeMetric} onChange={event => changeMetric(event.target.value as Metric | '')}>
          <option value="">Todos os territórios</option>
          {Object.entries(metrics).filter(([, meta]) => national ? !meta.municipal : meta.municipal && state.year === 2026)
            .map(([key, item]) => <option value={key} key={key}>{item.name}</option>)}
        </select></label>
        {activeMetric && <><p className="subtle">{metricYear ?? 'Sem ano disponível'} · {metrics[activeMetric].unit}</p>
          <div className="two-inputs">
            <label>Mínimo<input type="number" step="any" placeholder="Qualquer" value={range.min} onChange={event => setRange({ ...range, min: event.target.value })} /></label>
            <label>Máximo<input type="number" step="any" placeholder="Qualquer" value={range.max} onChange={event => setRange({ ...range, max: event.target.value })} /></label>
          </div>
          <p className="subtle"><a href={metrics[activeMetric].url} target="_blank" rel="noreferrer">{metrics[activeMetric].source}</a></p></>}
        {!activeMetric && <p className="subtle">{!national && state.year !== 2026 ? 'Os filtros municipais estão disponíveis na eleição de 2026.' : 'Escolha um indicador para comparar territórios com valores na mesma faixa.'}</p>}
        {state.mode === 'shift' && <div className="flip-count"><strong>{integer(flipCount)}</strong><span>{national ? (flipCount === 1 ? 'UF' : 'UFs') : (flipCount === 1 ? 'localidade' : 'localidades')} com inversão entre os finalistas</span></div>}
      </section>
      <section className="surface chart-card">
        <div className="section-head"><div><p className="label">GRÁFICO DE DISPERSÃO</p><h2>{compareContext ? 'Indicador e votação' : 'Do primeiro ao segundo turno'}</h2></div>
          {activeMetric && <label className="compact-control">Comparar<select value={chartType} onChange={event => setChartType(event.target.value as 'turns' | 'context')}>
            <option value="context">Indicador e votação</option><option value="turns">Margem entre turnos</option>
          </select></label>}
        </div>
        {compareContext && state.office === 'P' && race && <label className="compact-control">Candidato<select value={selectedCandidate?.id ?? ''} onChange={event => setCandidate(event.target.value)}>
          {race.candidates.filter(item => state.mode !== '2' || race.pair.includes(item.id)).map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
        </select></label>}
        {compareContext && state.office === 'G' && <label className="compact-control">Medida<select value={measure} onChange={event => setMeasure(event.target.value as 'margin' | 'turnout')}>
          <option value="margin">Margem no 1º turno</option><option value="turnout">Comparecimento no turno selecionado</option>
        </select></label>}
        <p className="subtle chart-axis">{axes[1]}{compareContext ? ` · ${state.office === 'G' && measure === 'margin' || state.mode !== '2' ? '1º turno' : '2º turno'}` : ' · Pontos laranja indicam inversão de liderança.'}</p>
        {pointsData.length ? <Suspense fallback={<div className="chart-host" />}>
          <Chart option={chartOption} label={axes.join(' por ')} select={detailSelect} />
        </Suspense> : <p className="empty-chart">Sem pontos para este recorte.</p>}
      </section>
    </div>
    <section className="surface table-card">
      <div className="section-head"><div><p className="label">RESULTADOS POR TERRITÓRIO</p><h2>{national ? 'Consultar uma UF' : 'Buscar um município'}</h2></div>
        <label className="search-box"><Search size={18} /><input type="search" aria-label={national ? 'Buscar UF' : 'Buscar município'} value={query} onChange={event => setQuery(event.target.value)} placeholder={national ? 'Nome da UF' : 'Nome do município'} /></label>
      </div>
      <div className="table-scroll">
        <table><thead><tr><th scope="col">Localidade</th><th scope="col">Votos válidos</th><th scope="col">{state.mode === 'shift' ? 'Mudança de margem' : 'Margem'}</th>
          {activeMetric && <th scope="col">{metrics[activeMetric].name} · {metricYear}</th>}{national && <th scope="col">Municípios</th>}</tr></thead>
          <tbody>{displayed.slice(0, expanded ? undefined : 10).map(item => {
            const tally = state.mode === 'shift' ? item.second : item.current
            return <tr key={item.id} className={state.selected === item.id ? 'selected-row' : ''}>
              <th scope="row"><button className="text-button" onClick={() => detailSelect(item.id)}>{item.name}</button></th>
              <td>{tally ? integer(tally[2]) : '—'}</td><td>{points(item.value, state.mode === 'shift' || !crossStateGovernor)}</td>
              {activeMetric && <td>{item.index === undefined ? '—' : metricValue(activeMetric, item.index)}</td>}
              {national && <td><button className="text-button" onClick={() => open(item.id)} aria-label={`Abrir municípios de ${item.name}`}>Abrir <ArrowRight size={13} /></button></td>}
            </tr>
          })}</tbody>
        </table>
      </div>
      {displayed.length === 0 && <p className="subtle">Nenhuma localidade para esta busca e faixa.</p>}
      {displayed.length > 10 && <button className="text-button show-more" onClick={() => setExpanded(!expanded)}>{expanded ? 'Mostrar menos' : `Mostrar todas as ${integer(displayed.length)} localidades`}</button>}
    </section>
  </>
}
