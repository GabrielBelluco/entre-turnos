export type Office = 'P' | 'G'
export type Round = 1 | 2
export type Mode = 'shift' | '1' | '2'
export type Page = 'atlas' | 'evolucao' | 'metodologia'
export type Metric = 'idhm' | 'homicides' | 'jobs' | 'income' | 'idhmMunicipal' | 'literacy'
export type Counts = [eligible: number, turnout: number, valid: number, blank: number, invalid: number, votes: Record<string, number>]
export type Rounds = Partial<Record<Round, Counts>>
export type LocationResults = Partial<Record<Office, Rounds>>
export type Candidate = { id: string; name: string; party: string; number: string; elected: boolean }
export type Race = { rounds: Round[]; pair: string[]; candidates: Candidate[] }
export type Manifest = {
  years: number[]
  ufs: Record<string, { id: string; name: string }>
  locations: Record<string, { name: string; uf: string }>
  races: Record<string, Record<string, Race>>
  snapshots: Record<string, string[]>
  pilot: boolean
}
export type Results = { rows: Record<string, LocationResults>; domestic?: Rounds }
export type Observation = { id: string; year: number; metric: Metric; value: number }
export type Term = { id: string; name: string; start: string; end: string | null; source: string; note?: string }
export type Context = { indicators: Observation[]; terms: Term[] }

export const metrics: Record<Metric, { name: string; unit: string; source: string; url: string; municipal?: boolean }> = {
  idhm: { name: 'IDHM', unit: 'índice de 0 a 1', source: 'PNUD, FJP e IBGE', url: 'https://www.undp.org/pt/brazil/publications/radar-idhm-evolucao-do-idhm-e-de-seus-componentes-periodo-de-2012-2024' },
  homicides: { name: 'Homicídios registrados', unit: 'por 100 mil habitantes', source: 'Ipea / FBSP · Atlas da Violência 2026', url: 'https://repositorio.ipea.gov.br/entities/publication/9ab87dfc-33eb-4ac2-8a54-f4f1543dabbc' },
  jobs: { name: 'Desocupação', unit: '%', source: 'IBGE · PNAD Contínua', url: 'https://sidra.ibge.gov.br/tabela/10361' },
  income: { name: 'Renda domiciliar por pessoa', unit: 'R$ a preços do último ano da série', source: 'IBGE · PNAD Contínua', url: 'https://sidra.ibge.gov.br/tabela/7533' },
  idhmMunicipal: { name: 'IDHM municipal', unit: 'índice de 0 a 1', source: 'Atlas do Desenvolvimento Humano', url: 'https://www.undp.org/pt/brazil/idhm-municipios-2010', municipal: true },
  literacy: { name: 'Alfabetização (15+)', unit: '%', source: 'IBGE · Censo 2022', url: 'https://sidra.ibge.gov.br/tabela/9543', municipal: true },
}

export const officeNames = { P: 'Presidente', G: 'Governador' }
export const integer = (value: number) => new Intl.NumberFormat('pt-BR').format(value)
export const decimal = (value: number, digits = 1) => new Intl.NumberFormat('pt-BR', { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(value)
export const percent = (value: number | null) => value === null ? '—' : `${decimal(value)}%`
export const points = (value: number | null, signed = false) => value === null ? '—' : `${signed && value > 0 ? '+' : ''}${decimal(value)} p.p.`
export const metricValue = (metric: Metric, value: number) => {
  if (metric === 'idhm' || metric === 'idhmMunicipal') return decimal(value, 3)
  if (metric === 'income') return `R$ ${integer(value)}`
  if (metric === 'jobs' || metric === 'literacy') return percent(value)
  return decimal(value)
}
export const normalize = (text: string) => text.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLocaleLowerCase('pt-BR')
export const share = (votes: number, valid: number) => valid > 0 ? 100 * votes / valid : null
export const raceFor = (manifest: Manifest, year: number, office: Office, uf: string) =>
  manifest.races[year]?.[office === 'P' ? 'P-BR' : `G-${uf}`]

export function margin(counts: Counts | undefined, pair: string[] | undefined) {
  if (!counts || !pair || pair.length < 2) return null
  return share((counts[5][pair[0]] ?? 0) - (counts[5][pair[1]] ?? 0), counts[2])
}

export function topMargin(counts: Counts | undefined) {
  if (!counts) return null
  const [first = 0, second = 0] = Object.values(counts[5]).sort((a, b) => b - a)
  return share(first - second, counts[2])
}

export const inversion = (first: number | null, second: number | null) =>
  first !== null && second !== null && Math.sign(first) * Math.sign(second) === -1

export function referenceYear(rows: Observation[], metric: Metric, election: number, territoryIds: string[]) {
  const relevant = rows.filter(row => row.metric === metric && row.year < election && territoryIds.includes(row.id))
  const years = [...new Set(relevant.map(row => row.year))].sort((a, b) => b - a)
  return years.find(year => territoryIds.every(id => relevant.some(row => row.year === year && row.id === id))) ?? years[0]
}

export function dataUrl(name: string) {
  return `${import.meta.env.BASE_URL}data/${name}`
}
