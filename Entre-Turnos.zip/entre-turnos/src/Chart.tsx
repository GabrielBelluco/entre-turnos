import { useEffect, useRef } from 'react'
import { init, use, type EChartsCoreOption } from 'echarts/core'
import { LineChart, ScatterChart } from 'echarts/charts'
import { CanvasRenderer } from 'echarts/renderers'
import { GridComponent, TooltipComponent, MarkLineComponent, LegendComponent, AriaComponent } from 'echarts/components'

use([LineChart, ScatterChart, CanvasRenderer, GridComponent, TooltipComponent, MarkLineComponent, LegendComponent, AriaComponent])

export default function Chart({ option, label, select }: { option: EChartsCoreOption; label: string; select?: (id: string) => void }) {
  const host = useRef<HTMLDivElement>(null)
  const chart = useRef<ReturnType<typeof init> | null>(null)
  const handler = useRef(select)
  handler.current = select
  useEffect(() => {
    if (!host.current) return
    const instance = init(host.current, undefined, { renderer: 'canvas' })
    chart.current = instance
    instance.on('click', params => {
      const datum = params.data as { id?: string } | undefined
      if (datum?.id) handler.current?.(datum.id)
    })
    const observer = new ResizeObserver(() => instance.resize())
    observer.observe(host.current)
    return () => { observer.disconnect(); instance.dispose(); chart.current = null }
  }, [])
  useEffect(() => { chart.current?.setOption(option, { notMerge: true }) }, [option])
  return <div className="chart-host" role="img" aria-label={label} ref={host} />
}
