import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';

const reportName = 'Entre Turnos';
const folder = 'bi';
const report = join(folder, `${reportName}.Report`);
const model = join(folder, `${reportName}.SemanticModel`);
const schemaRoot = 'https://developer.microsoft.com/json-schemas/fabric';
const schema = (path, version = '1.0.0') => `${schemaRoot}/${path}/${version}/schema.json`;

async function write(path, value) {
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, JSON.stringify(value, null, 2) + '\n', 'utf8');
}

const tables = [
  { name: 'UF', csv: 'states', fields: { uf: 'string', name: 'string' } },
  { name: 'Município', csv: 'municipalities', fields: { id: 'string', name: 'string', uf: 'string' } },
  { name: 'Candidato', csv: 'candidates', fields: { id: 'string', name: 'string', party: 'string' } },
  { name: 'Ano eleitoral', csv: 'years', fields: { year: 'int64' } },
  { name: 'Turno', csv: 'rounds', fields: { round: 'int64', label: 'string' } },
  { name: 'Cargo', csv: 'offices', fields: { office: 'string' } },
  { name: 'Votos', csv: 'votes', fields: { year: 'int64', office: 'string', round: 'int64', id: 'string', candidate: 'string', votes: 'int64' } },
  { name: 'Apuração', csv: 'counts', fields: { year: 'int64', office: 'string', round: 'int64', id: 'string',
    eligible: 'int64', turnout: 'int64', valid: 'int64', blank: 'int64', invalid: 'int64' } },
  { name: 'Indicadores UF', csv: 'indicators', fields: { id: 'string', year: 'int64', metric: 'string', value: 'double' },
    transform: 'Table.SelectRows(Tipos, each Text.Length([id]) = 2 and [id] <> "BR")',
    derived: { Indicador: 'switchMetric' } },
  { name: 'Indicadores município', csv: 'indicators', fields: { id: 'string', year: 'int64', metric: 'string', value: 'double' },
    transform: 'Table.SelectRows(Tipos, each Text.Length([id]) = 7)' },
  { name: 'Mandatos', csv: 'terms', fields: { id: 'string', name: 'string', start: 'dateTime', end: 'dateTime', source: 'string', note: 'string' },
    transform: 'Table.SelectRows(Tipos, each [id] <> "BR")' },
];

const typeM = { string: 'type text', int64: 'Int64.Type', double: 'type number', dateTime: 'type date' };
const fieldsTitles = {
  year: 'Ano', uf: 'Sigla', name: 'Nome', party: 'Partido', office: 'Cargo', label: 'Turno',
  eligible: 'Aptos', turnout: 'Votantes', valid: 'Votos válidos (contagem)', votes: 'Votos nominais',
  blank: 'Brancos', invalid: 'Nulos', value: 'Valor publicado', start: 'Posse', end: 'Fim', source: 'Fonte', note: 'Observação',
};
const columnName = (field) => fieldsTitles[field] ?? field;
const literals = {
  idhm: 'IDHM', homicides: 'Homicídios por 100 mil', jobs: 'Desocupação (%)', income: 'Renda real por pessoa (R$)',
};
const payloads = new Map();

async function loadCsv(name) {
  if (!payloads.has(name)) {
    const csv = await readFile(join(folder, 'data', `${name}.csv`), 'utf8');
    const payload = gzipSync(csv, { level: 9 }).toString('base64');
    payloads.set(name, payload.match(/.{1,12000}/g));
  }
  return payloads.get(name);
}

const measure = (name, expression, formatString) => ({ name, expression, formatString });
const filterElection = (table, column, fn) => `VAR Ano = SELECTEDVALUE('Ano eleitoral'[Ano], 2026)
VAR CargoEscolhido = SELECTEDVALUE('Cargo'[Cargo], "Presidente")
VAR TurnoEscolhido = SELECTEDVALUE('Turno'[round], 2)
RETURN CALCULATE(${fn}('${table}'[${column}]), KEEPFILTERS('Ano eleitoral'[Ano] = Ano), KEEPFILTERS('Cargo'[Cargo] = CargoEscolhido), KEEPFILTERS('Turno'[round] = TurnoEscolhido))`;
const measures = {
  Votos: [
    measure('Votos do candidato', filterElection('Votos', 'Votos nominais', 'SUM'), '#,0'),
    measure('Percentual do candidato', 'DIVIDE([Votos do candidato], [Votos válidos])', '0.00%'),
  ],
  Apuração: [
    measure('Votos válidos', filterElection('Apuração', 'Votos válidos (contagem)', 'SUM'), '#,0'),
    measure('Comparecimento', 'DIVIDE([Votantes no recorte], [Eleitores aptos])', '0.00%'),
    measure('Votantes no recorte', filterElection('Apuração', 'Votantes', 'SUM'), '#,0'),
    measure('Eleitores aptos', filterElection('Apuração', 'Aptos', 'SUM'), '#,0'),
  ],
  'Indicadores UF': [
    measure('Valor do indicador', `VAR Metrica = SELECTEDVALUE('Indicadores UF'[metric], "homicides")
RETURN IF(HASONEVALUE('UF'[Sigla]), CALCULATE(SELECTEDVALUE('Indicadores UF'[Valor publicado]), KEEPFILTERS('Indicadores UF'[metric] = Metrica)))`, '#,0.###'),
  ],
};

async function modelTable(table) {
  const data = await loadCsv(table.csv);
  const columns = Object.entries(table.fields).map(([field, dataType]) => ({
    name: columnName(field), dataType, sourceColumn: field, summarizeBy: 'none',
    ...(dataType === 'dateTime' ? { formatString: 'dd/MM/yyyy' } : {}),
  }));
  if (table.derived?.Indicador) columns.push({
    name: 'Indicador', dataType: 'string', sourceColumn: 'Indicador', summarizeBy: 'none',
  });
  const types = Object.entries(table.fields).map(([field, type]) => `{"${field}", ${typeM[type]}}`).join(', ');
  const conditions = Object.entries(literals).map(([key, label]) => `if [metric] = "${key}" then "${label}" else `).join('');
  return {
    name: table.name, columns,
    ...(measures[table.name] ? { measures: measures[table.name] } : {}),
    partitions: [{
      name: table.name, mode: 'import', source: {
        type: 'm', expression: [
          'let',
          '    TextoCompactado = Text.Combine({',
          ...data.map((part, i) => `        "${part}"${i + 1 === data.length ? '' : ','}`),
          '    }),',
          '    Origem = Binary.Decompress(Binary.FromText(TextoCompactado, BinaryEncoding.Base64), Compression.GZip),',
          `    CSV = Csv.Document(Origem, [Delimiter=",", Columns=${Object.keys(table.fields).length}, Encoding=65001, QuoteStyle=QuoteStyle.Csv]),`,
          '    Cabeçalhos = Table.PromoteHeaders(CSV, [PromoteAllScalars=true]),',
          `    Tipos = Table.TransformColumnTypes(Cabeçalhos, {${types}}, "en-US"),`,
          `    Recorte = ${table.transform ?? 'Tipos'}${table.derived ? ',' : ''}`,
          ...(table.derived ? [`    Rotulos = Table.AddColumn(Recorte, "Indicador", each ${conditions} [metric], type text)`] : []),
          `in ${table.derived ? 'Rotulos' : 'Recorte'}`,
        ],
      },
    }],
  };
}

const relationship = (fromTable, fromField, toTable, toField) => ({
  name: createHash('sha256').update(`${fromTable}/${fromField}/${toTable}/${toField}`).digest('hex').slice(0, 32),
  fromTable, fromColumn: columnName(fromField), toTable, toColumn: columnName(toField),
});
const relationships = [
  relationship('Município', 'uf', 'UF', 'uf'),
  ...['Votos', 'Apuração'].flatMap(table => [
    relationship(table, 'id', 'Município', 'id'),
    relationship(table, 'year', 'Ano eleitoral', 'year'),
    relationship(table, 'round', 'Turno', 'round'),
    relationship(table, 'office', 'Cargo', 'office'),
  ]),
  relationship('Votos', 'candidate', 'Candidato', 'id'),
  relationship('Indicadores UF', 'id', 'UF', 'uf'),
  relationship('Indicadores município', 'id', 'Município', 'id'),
  relationship('Mandatos', 'id', 'UF', 'uf'),
];

await write(join(model, 'definition.pbism'), {
  $schema: schema('item/semanticModel/definitionProperties'), version: '1.0', settings: {},
});
await write(join(model, 'model.bim'), {
  name: reportName, compatibilityLevel: 1601,
  model: { culture: 'pt-BR', sourceQueryCulture: 'pt-BR', defaultPowerBIDataSourceVersion: 'powerBI_V3',
    annotations: [{ name: '__PBI_TimeIntelligenceEnabled', value: '0' }], tables: await Promise.all(tables.map(modelTable)), relationships },
});

await write(join(folder, `${reportName}.pbip`), {
  $schema: schema('pbip/pbipProperties'), version: '1.0', artifacts: [{ report: { path: `${reportName}.Report` } }],
  settings: { enableAutoRecovery: true },
});
await write(join(report, 'definition.pbir'), {
  $schema: schema('item/report/definitionProperties', '2.0.0'), version: '4.0',
  datasetReference: { byPath: { path: `../${reportName}.SemanticModel` } },
});
const definition = join(report, 'definition');
await write(join(definition, 'report.json'), {
  $schema: schema('item/report/definition/report', '3.1.0'),
  themeCollection: {},
  settings: { defaultDrillFilterOtherVisuals: true },
});
await write(join(definition, 'version.json'), {
  $schema: schema('item/report/definition/versionMetadata'),
  version: '2.0.0',
});
const pages = ['ReportSectionEleicoes', 'ReportSectionIndicadores'];
await write(join(definition, 'pages', 'pages.json'), {
  $schema: schema('item/report/definition/pagesMetadata'), pageOrder: pages, activePageName: pages[0],
});
for (const [index, id] of pages.entries()) {
  await write(join(definition, 'pages', id, 'page.json'), {
    $schema: schema('item/report/definition/page'), name: id,
    displayName: ['Eleições', 'Indicadores e governos'][index], displayOption: 'FitToPage', width: 1280, height: 720,
  });
}

const entry = (table, property, kind = 'Column') => ({
  field: { [kind]: { Expression: { SourceRef: { Entity: table } }, Property: property } },
  queryRef: `${table}.${property}`, nativeQueryRef: property,
});
const literal = value => ({ expr: { Literal: { Value: value } } });
const stringLiteral = value => literal(`'${value.replaceAll("'", "''")}'`);
const slicer = (table, column) => ({ Values: [entry(table, column)] });
const card = (table, name) => ({ Data: [entry(table, name, 'Measure')] });
const visuals = [
  [
    ['slicer', 'Ano eleitoral', 22, 18, 170, 86, slicer('Ano eleitoral', 'Ano')],
    ['slicer', 'Cargo', 210, 18, 240, 86, slicer('Cargo', 'Cargo')],
    ['slicer', 'Turno', 468, 18, 190, 86, slicer('Turno', 'Turno')],
    ['slicer', 'UF', 676, 18, 268, 86, slicer('UF', 'Nome')],
    ['cardVisual', 'Votos válidos', 22, 120, 295, 111, card('Apuração', 'Votos válidos')],
    ['cardVisual', 'Comparecimento', 335, 120, 295, 111, card('Apuração', 'Comparecimento')],
    ['cardVisual', 'Eleitores aptos', 650, 120, 295, 111, card('Apuração', 'Eleitores aptos')],
    ['clusteredBarChart', 'Votação por candidato', 22, 249, 1225, 442, {
      Category: [entry('Candidato', 'Nome')], Y: [entry('Votos', 'Votos do candidato', 'Measure')],
      Tooltips: [entry('Votos', 'Percentual do candidato', 'Measure')],
    }],
  ],
  [
    ['slicer', 'UF', 22, 18, 325, 86, slicer('UF', 'Nome')],
    ['slicer', 'Indicador', 367, 18, 399, 86, slicer('Indicadores UF', 'Indicador')],
    ['lineChart', 'Série anual por UF', 22, 120, 1225, 324, {
      Category: [entry('Indicadores UF', 'Ano')], Y: [entry('Indicadores UF', 'Valor do indicador', 'Measure')],
      Series: [entry('UF', 'Sigla')],
    }],
    ['tableEx', 'Cronologia de governadores', 22, 464, 1225, 226, {
      Values: [entry('UF', 'Sigla'), ...['Nome','Posse','Fim','Observação'].map(name => entry('Mandatos', name))],
    }],
  ],
];

for (const [pageIndex, items] of visuals.entries()) {
  for (const [index, [visualType, title, x, y, width, height, roles]] of items.entries()) {
    const name = createHash('sha256').update(`${pageIndex}/${index}`).digest('hex').slice(0, 20);
    const query = { queryState: Object.fromEntries(Object.entries(roles).map(([key, projections]) => [key, { projections }])) };
    if (visualType === 'clusteredBarChart') query.sortDefinition = { sort: [{ field: roles.Y[0].field, direction: 'Descending' }] };
    const visual = {
      visualType, query, drillFilterOtherVisuals: true,
      visualContainerObjects: { title: [{ properties: { show: literal('true'), text: stringLiteral(title) } }] },
    };
    if (visualType === 'slicer') visual.objects = { selection: [{ properties: { singleSelect: literal('true') } }] };
    await write(join(definition, 'pages', pages[pageIndex], 'visuals', name, 'visual.json'), {
      $schema: schema('item/report/definition/visualContainer', '2.4.0'), name,
      position: { x, y, width, height, z: index, tabOrder: index }, visual,
    });
  }
}
console.log(`Power BI · ${tables.length} tabelas, ${relationships.length} relacionamentos e ${pages.length} páginas.`);
