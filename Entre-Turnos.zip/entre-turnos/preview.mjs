import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { extname, isAbsolute, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = fileURLToPath(new URL('./dist/', import.meta.url));
const port = Number(process.env.ENTRE_TURNOS_PORT ?? 4175);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.geojson': 'application/geo+json' };

createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    const name = decodeURIComponent(url.pathname === '/' ? 'index.html' : url.pathname.slice(1));
    const file = resolve(directory, name);
    const path = relative(directory, file);
    if (path.startsWith('..') || isAbsolute(path) || !(await stat(file)).isFile()) throw new Error('not found');
    response.setHeader('Content-Type', (types[extname(file)] ?? 'application/octet-stream') + '; charset=UTF-8');
    if (request.method === 'HEAD') response.end();
    else createReadStream(file).pipe(response);
  } catch {
    response.writeHead(404, { 'Content-Type': 'text/plain; charset=UTF-8' }).end('Arquivo indisponível. Rode npm run build para gerar dist/.');
  }
}).listen(port, '127.0.0.1', () => console.log(`Entre Turnos está disponível em http://127.0.0.1:${port}/`));
